using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Medkit : MonoBehaviour
{
    public float medkitValue;
    public string medkitTag;

    private void OnCollisionEnter(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }

    private void OnTriggerEnter(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }

    void collisionProcess(GameObject ob)
    {
        if (ob.tag == medkitTag)
        {
            GetComponent<HP>().addHP(medkitValue);
            Destroy(ob);
        }
    }
}


