﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float distance;
    public float attackDistance;
    public float speed;
    Animator animator;
    GameObject player;
    Rigidbody rb;
    bool isInAttack = false;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        Vector3 direction = player.transform.position - transform.position;
        direction.y = 0;
        transform.rotation = Quaternion.LookRotation(direction);
        if (direction.magnitude < distance)
        {
            if (Vector3.Distance(player.transform.position, transform.position) > attackDistance)
            {

                animator.SetBool("walk", true);
                animator.SetBool("attack", false);
                if (!isInAttack)
                    rb.velocity = new Vector3(transform.forward.x * speed, rb.velocity.y, transform.forward.z * speed);
            }
            else
            {
                animator.SetBool("attack", true);
                animator.SetBool("walk", false);
                Invoke("delay", animator.GetCurrentAnimatorStateInfo(0).length);
                isInAttack = true;
                rb.velocity = new Vector3(0, rb.velocity.y, 0);
            }
        }
        else
        {
            rb.velocity = new Vector3(0, rb.velocity.y, 0);
            animator.SetBool("walk", false);
            animator.SetBool("attack", false);
        }
    }

    void delay()
    {
        isInAttack = false;
    }
}