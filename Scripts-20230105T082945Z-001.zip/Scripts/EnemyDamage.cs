using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDamage : MonoBehaviour
{
    public float damage;
    public float damageTimeOut;
    bool timeout = true;

    private void OnCollisionEnter(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnCollisionStay(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnTriggerEnter(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnTriggerStay(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }
    void collisionProcess(GameObject ob)
    {
        if (ob.GetComponent<EnemyHP>() && timeout)
        {
            timeout = false;
            Invoke("timeOut", damageTimeOut);
            ob.GetComponent<EnemyHP>().damage(damage);
        }
    }
    void timeOut()
    {
        timeout = true;
    }
}
