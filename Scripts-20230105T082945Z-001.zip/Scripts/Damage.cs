using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour
{

    public float damage;
    public float damageTimeOut;
    public string damageTag;
    bool timeout = true;

    private void OnCollisionEnter(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnCollisionStay(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnTriggerEnter(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnTriggerStay(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }

    void collisionProcess(GameObject ob)
    {
        if (ob.tag == damageTag && timeout)
        {
            timeout = false;
            Invoke("timeOut", damageTimeOut);
            GetComponent<HP>().addHP(-damage);
        }
    }

    void timeOut()
    {
        timeout = true;
    }
}
