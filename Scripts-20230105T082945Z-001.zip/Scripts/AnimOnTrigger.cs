﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimOnTrigger : MonoBehaviour
{
    public GameObject animObject;
    public string animationName;
    Animator animator;
    private void Start()
    {
        animator = animObject.GetComponent<Animator>();
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Player")
            animator.Play(animationName);
    }
}


