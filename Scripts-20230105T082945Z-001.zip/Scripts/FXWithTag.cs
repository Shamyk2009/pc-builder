﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FXWithTag : MonoBehaviour {
    AudioSource audioSource;
    public string obj_tag;
    public AudioClip clip;
    private void Start()
    {
        
        audioSource = Camera.main.gameObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == tag)
        {
            if(!audioSource.isPlaying)
            audioSource.Play();
        }
    }
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == tag)
        {
            if(!audioSource.isPlaying)
            audioSource.Play();
        }
    }
}
