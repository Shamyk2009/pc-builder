using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class speedonkeyboard : MonoBehaviour
{
    public float speedMultiplier = 2.0f;
    RigidbodyFirstPersonController controller;
    private bool pressed = false;
    void Start()
    {
        controller = GetComponent<RigidbodyFirstPersonController>();
        if (speedMultiplier <= 0)
            speedMultiplier = 0.01f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (pressed == false)
            {
                controller.movementSettings.ForwardSpeed *= speedMultiplier;
                controller.movementSettings.BackwardSpeed *= speedMultiplier;
                controller.movementSettings.StrafeSpeed *= speedMultiplier;
                pressed = true;
            }
            else if (pressed == true)
            {
                controller.movementSettings.ForwardSpeed /= speedMultiplier;
                controller.movementSettings.BackwardSpeed /= speedMultiplier;
                controller.movementSettings.StrafeSpeed /= speedMultiplier;
                pressed = false;
            }
        }
    }
}


