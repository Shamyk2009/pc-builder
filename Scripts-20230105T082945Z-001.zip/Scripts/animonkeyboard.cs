using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class animonkeyboard: MonoBehaviour
{
    public GameObject animObject;
    public string animationName;
    public string animationName_2;
    private bool played = false;
    Animator animator;

    private void Start()
    {
        animator = animObject.GetComponent<Animator>();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (played == false)
            {
                animator.Play(animationName); 
                played = true;
                Debug.Log(played);
            }
            else if (played == true)
            {
                animator.Play(animationName_2);
                played = false;
                Debug.Log(played);
            }
        }
    }
}
