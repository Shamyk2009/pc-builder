﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class basicNPC : MonoBehaviour
{  
    GameObject player;    
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
;
    }
    void Update()
    {
        if (Vector3.Distance(player.transform.position, transform.position) < 5)
        {
            Vector3 direction = player.transform.position - transform.position;
            direction.y = 0;
            transform.rotation = Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(direction),0.1f);
        }
    }
}
