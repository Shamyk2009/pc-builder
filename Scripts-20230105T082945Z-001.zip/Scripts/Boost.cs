﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class Boost : MonoBehaviour
{
    public float speedMultiplier = 2.0f;
    public float time;
    public string boostpadTag;
    RigidbodyFirstPersonController controller;

    void Start()
    {
        controller = GetComponent<RigidbodyFirstPersonController>();
        if (speedMultiplier <= 0)
            speedMultiplier = 0.01f;
    }

    void OnTriggerEnter(Collider boostpad)
    {
        if (boostpad.tag == boostpadTag)
        {
            controller.movementSettings.ForwardSpeed *=speedMultiplier;
            controller.movementSettings.BackwardSpeed *= speedMultiplier;
            controller.movementSettings.StrafeSpeed *= speedMultiplier;
            Destroy(boostpad.gameObject);
            Invoke("DefaultSpeed", time);
        }
    }
    void DefaultSpeed()
    {
        controller.movementSettings.ForwardSpeed /= speedMultiplier;
        controller.movementSettings.BackwardSpeed /= speedMultiplier;
        controller.movementSettings.StrafeSpeed /= speedMultiplier;
    }
}