﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestSystem : MonoBehaviour
{
    public Text staticTextOb;
    public Text dynamicTextOb;
    public Image arrow;
    public string firstQuestText;
    public List<GameObject> questObjects;
    public List<string> questTexts;
    public List<bool> destroyObject;
    Vector3 direction;
    IEnumerator coroutine;

    private void Start()
    {
        clear();
        staticTextOb.text = firstQuestText;
        coroutine = print(firstQuestText);
        StartCoroutine(coroutine);
    }

    private void Update()
    {
        if (questObjects.Count > 0)
        {
            direction = (questObjects[0].transform.position - transform.position).normalized;
            direction += new Vector3(0, -direction.y, 0);
            arrow.rectTransform.rotation = Quaternion.Euler(0, 0, -Vector3.SignedAngle(transform.forward - new Vector3(0, transform.forward.y, 0), direction, Vector3.up));
        }
        else
            arrow.gameObject.SetActive(false);
    }

    private void OnCollisionEnter(Collision collision)
    {
        collisionProcess(collision.gameObject);
    }
    private void OnTriggerEnter(Collider collision)
    {
        collisionProcess(collision.gameObject);
    }

    void collisionProcess(GameObject ob)
    {
        if (questObjects.Count > 0)
            if (ob == questObjects[0])
            {
                staticTextOb.text = questTexts[0];                
                clear();
                StopCoroutine(coroutine);
                coroutine = print(questTexts[0]);
                StartCoroutine(coroutine);
                questObjects.RemoveAt(0);
                questTexts.RemoveAt(0);
                if (destroyObject[0])
                    Destroy(ob);
                destroyObject.RemoveAt(0);
            }
    }

    IEnumerator print(string str)
    {
        while(str.Length>0)
        {
            dynamicTextOb.text += str[0];
            str=str.Remove(0, 1);
            yield return new WaitForSeconds(0.1f);
            //this.Invoke(() => print(str), 0.1f);
        }
            Invoke("clear", 1f);
    }
    void clear()
    {
        dynamicTextOb.text = "";
    }
}
