using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHP : MonoBehaviour
{
    public float timeToDestroy;
    float hp = 100;
    bool alive = true;
    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    public void damage(float points)
    {
        if (hp > 0)
            hp = hp - points;
        if (hp <= 0 && alive)
        {
            hp = 0;
            alive = false;
            Destroy(gameObject, timeToDestroy);
            GetComponent<Enemy>().enabled = false;
            foreach (Collider collider in GetComponentsInChildren<Collider>())
            {
                collider.enabled = false;
            }
            GetComponent<Collider>().enabled = true;
            GetComponent<Animator>().enabled = false;
            GetComponent<Rigidbody>().constraints = 0;
        }
    }
}
