﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FXWithObj : MonoBehaviour {
    AudioSource audioSource;
    public GameObject obj;
    public AudioClip clip;
    private void Start()
    {
        
        audioSource = Camera.main.gameObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject==obj)
        {
            if(!audioSource.isPlaying)
            audioSource.Play();
        }
    }
    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject == obj)
        {
            if (!audioSource.isPlaying)
                audioSource.Play();
        }
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject==obj)
        {
            if(!audioSource.isPlaying)
            audioSource.Play();
        }
    }
    private void OnTriggerStay(Collider collision)
    {
        if (collision.gameObject == obj)
        {
            if (!audioSource.isPlaying)
                audioSource.Play();
        }
    }
}
