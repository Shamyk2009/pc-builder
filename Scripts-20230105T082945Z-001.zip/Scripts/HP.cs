﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityStandardAssets.Characters.FirstPerson;

public class HP : MonoBehaviour
{
    public Slider sliderObject;
    float hp = 100;
    bool alive = true;


    public void addHP(float points)
    {
        if (hp > 0)
            hp = hp + points;
        if (hp > 100)
            hp = 100;
        if (hp <= 0 && alive)
        {
            hp = 0;
            alive = false;
            GetComponent<RigidbodyFirstPersonController>().enabled = false;
            GetComponent<Rigidbody>().constraints = 0;
            Invoke("restartLevel",5);
        } 
    }

    void Update()
    {
        sliderObject.value = hp / 100;
        if (!alive && transform.rotation.x < 90)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(-90, 0, 0), 0.1f);
        }
    }

    void restartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}