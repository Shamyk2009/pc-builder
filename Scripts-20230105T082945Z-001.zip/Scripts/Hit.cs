﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hit : MonoBehaviour
{
    public string animationName;
    public int mouseButton;

    void Update()
    {        
        if (Input.GetMouseButtonDown(mouseButton))  
        {
            GetComponent<Animator>().Play(animationName);
        }
        if(GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody>().constraints == 0)
        {
            gameObject.SetActive(false);
        }
    }
}


