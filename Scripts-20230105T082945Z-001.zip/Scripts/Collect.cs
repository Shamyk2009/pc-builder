using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Collect : MonoBehaviour
{    
    public string collectibleTag;
    public int howMuch;
    public string startText = "����� �������-�� ����-��";
    public string finishText = "������� ���������!";
    public float yOfText = 10;


    GameObject cam;
    GameObject canOb;
    Canvas can;
    GameObject textOb;
    Text text;

    void Start()
    {
        cam = GetComponentInChildren<Camera>().gameObject;
        cam.GetComponent<Camera>().nearClipPlane = 0.01f;
        canOb = new GameObject("Collect Canvas");
        canOb.transform.parent = cam.transform;
        canOb.AddComponent<Canvas>();
        can = canOb.GetComponent<Canvas>();
        can.renderMode = RenderMode.WorldSpace;
        can.worldCamera = cam.GetComponent<Camera>();
        canOb.transform.localPosition = new Vector3(0, 0, 0.3f);
        textOb = new GameObject();
        textOb.transform.parent = canOb.transform;
        textOb.AddComponent<Text>();
        text = textOb.GetComponent<Text>();
        text.alignment = TextAnchor.MiddleLeft;
        text.rectTransform.sizeDelta = new Vector2(1300, 180);
        text.fontSize = 60;
        text.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
        text.text = startText;
        textOb.transform.localScale = new Vector3(0.03f, 0.03f, 0.03f);
        canOb.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
        text.rectTransform.localPosition = new Vector3(-11f, yOfText, 0);
        canOb.transform.localRotation = Quaternion.Euler(0, 0, 0);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == collectibleTag)
        {
            Destroy(collision.gameObject);
            if (howMuch>0)
            {
                howMuch--;
                text.text = "�������� �����: " + howMuch.ToString();
            }
            if (howMuch==0)
            {
                text.text = finishText;
                Invoke("HideText", 5);
            }
        }
    }
    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == collectibleTag)
        {
            Destroy(collision.gameObject);
            if (howMuch > 0)
            {
                howMuch--;
                text.text = "�������� �����: " + howMuch.ToString();
            }
            if (howMuch == 0)
            {
                text.text = finishText;
                Invoke("HideText", 5);
            }
        }
    }

    void HideText()
    {
        text.text = "";
    }

}
