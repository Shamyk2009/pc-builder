﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace UnityStandardAssets.Characters.FirstPerson
{
    public class  FxHero: MonoBehaviour
    {
        AudioSource audioSource, audioSource2;
        public AudioClip walk;
        public float walkPitch;
        public AudioClip jump;
        public AudioClip landing;

        RigidbodyFirstPersonController controller;
        bool onGround = true;
        bool isFalling = false;
        void Start()
        {
            controller = GetComponent<RigidbodyFirstPersonController>();
            //Добавляем и настраиваем источник аудио для звука шагов
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.clip = walk;
            //Добавляем и настраиваем источник аудио для звуков прыжка и приземления
            audioSource2 = gameObject.AddComponent<AudioSource>();
            audioSource2.playOnAwake = false;
            audioSource2.loop = false;
        }
        void Update()
        {
            //Обработка звука ходьбы
            if (controller.Grounded && (Input.GetAxis("Horizontal")!=0|| Input.GetAxis("Vertical")!=0))
            {
                    if (controller.Running)
                        audioSource.pitch = controller.movementSettings.RunMultiplier * walkPitch;
                    else
                        audioSource.pitch = walkPitch;
                    if (!audioSource.isPlaying)
                        audioSource.Play();
            }
            else
            {
                audioSource.Stop();
            }

            //Обработка звуков прыжка и приземления после прыжка
            if (onGround && controller.Jumping)
            {
                onGround = false;
                audioSource2.clip = jump;
                if(!audioSource2.isPlaying)
                    audioSource2.Play();
            }
            if (!onGround && !controller.Jumping)
            {
                onGround = true;
                audioSource2.clip = landing;
                if (!audioSource2.isPlaying)
                    audioSource2.Play();
            }

            ////Обработка звука приземления после падения
            if (!controller.Grounded && GetComponent<Rigidbody>().velocity.y < -4f)
                isFalling = true;
            if (isFalling && controller.Grounded)
            {
                isFalling = false;
                audioSource2.clip = landing;
                if (!audioSource2.isPlaying)
                    audioSource2.Play();
            }
        }
    }
}